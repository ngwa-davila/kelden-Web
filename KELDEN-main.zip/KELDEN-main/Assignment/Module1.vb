﻿Module Module1

    Sub Main()
            Dim num1 As Double
            Dim num2 As Double
            Dim operation As String
            Dim result As Double

            ' Input numbers
            Console.Write("Enter the first number: ")
            num1 = Convert.ToDouble(Console.ReadLine())

            Console.Write("Enter the second number: ")
            num2 = Convert.ToDouble(Console.ReadLine())

            ' Input operation
            Console.WriteLine("Choose an operation (+, -, *, /): ")
            operation = Console.ReadLine()

            ' Use Select Case to perform calculation
            Select Case operation
                Case "+"
                    result = num1 + num2
                    Console.WriteLine("Result: " & result)

                Case "-"
                    result = num1 - num2
                    Console.WriteLine("Result: " & result)

                Case "*"
                    result = num1 * num2
                    Console.WriteLine("Result: " & result)

                Case "/"
                    If num2 <> 0 Then
                        result = num1 / num2
                        Console.WriteLine("Result: " & result)
                    Else
                        Console.WriteLine("Error: Cannot divide by zero.")
                    End If

                Case Else
                    Console.WriteLine("Invalid operation.")
            End Select

            Console.WriteLine("Press any key to exit.")
            Console.ReadKey()
        End Sub
    End Module